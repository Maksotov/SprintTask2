function closeOpenPhotos(k) {
    if(k === 0) document.getElementById("popupp").style.display = "none";
    else  document.getElementById("popupp").style.display = "block";
}